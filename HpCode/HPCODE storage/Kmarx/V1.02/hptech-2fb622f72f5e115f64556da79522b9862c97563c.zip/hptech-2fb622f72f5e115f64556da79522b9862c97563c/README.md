This is where I throw all my code and hope it sticks on the HPCoders server.
